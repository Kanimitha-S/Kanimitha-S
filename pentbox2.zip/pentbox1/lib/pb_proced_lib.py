import os
import sys
import time

# Global variables (these should be set according to your needs)
pb_log_enabled = True
pb_log_file = "pentbox.log"
protected_mode = True
text_color = True

# Write a line in the log.
def pb_write_log(line, modname):
    if pb_log_enabled:
        try:
            with open(pb_log_file, "a") as file:
                file.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')} - {modname} - {os.getenv('USER')}] {line}\n")
        except Exception as e:
            print(f"Error writing to log file: {e}")

# Is the machine a Windows box?
def is_windows():
    return os.name == "nt"

# Check if running user is root, or has permission.
def has_permission():
    if not protected_mode:
        return True
    else:
        if not is_windows() and os.geteuid() == 0:
            return True
        elif is_windows():
            return True
        else:
            return False

# Print with colors for Unix-like systems.
def title(string):
    if not text_color:
        print(string)
    elif not is_windows():
        print(f"\033[1m\033[40m\033[33m{string}\033[0m")  # Yellow, bold, on black.
    else:
        print(string)

def warning(string):
    if not text_color:
        print(string)
    elif not is_windows():
        print(f"\033[1m\033[31m{string}\033[0m")  # Red, bold.
    else:
        print(string)

# Default gets, command execution implemented.
def gets_pb():
    while True:
        ln = input()
        if ln.startswith("!"):
            os.system(ln[1:].strip())
            print("---")
            print("   -> ", end="")
        else:
            return ln

# Example usage
if __name__ == "__main__":
    print("Checking permissions...")
    if has_permission():
        title("Permission granted.")
    else:
        warning("Permission denied.")
    
    pb_write_log("This is a log entry", "ExampleModule")
    
    print("Enter a command (prefix with '!' to execute):")
    user_input = gets_pb()
    print(f"You entered: {user_input}")
