#!/usr/bin/env python3

# Copyright (C) 2012, 2013, 2014
# Minzsec
# www.facebook.com/rootnameshadow
#
# PenTBox (Penetration Testing Box)
#
# This file is part of PenTBox.
#
# PenTBox is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# PenTBox is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with PenTBox.  If not, see <http://www.gnu.org/licenses/>.

import os
import signal
import random
import time

###########################
##  BASIC CONFIGURATION  ##
###########################

# PenTBox can save a log tracking the results given by the modules.
# Format: [1970-01-01 00:00:00 - Module name - Username] Data
#
# THIS DOESN'T WORK BY THE MOMENT. TODO
#
# Default -> False
pb_log_enabled = False
pb_log_file = os.path.join(os.path.dirname(__file__), "other/log/pentbox_log_" + os.getenv('USER', 'default') + ".log")

# protected_mode variable defines if protected mode is activated or not.
#
# Protected mode protects you against "script kiddies" and "lammers". They
# can't run dangerous modules without root privileges.
#
# Recommended for public computers!!
#
# Default -> True
protected_mode = True

# text_color variable.
# When True, titles and warnings will be colorful,
# else it will be with default colors.
#
# Default -> True
text_color = True

###########################

def pb_write_log(message, module):
    if pb_log_enabled:
        with open(pb_log_file, 'a') as log_file:
            log_file.write(f"[{time.strftime('%Y-%m-%d %H:%M:%S')} - {module} - {os.getenv('USER', 'default')}] {message}\n")

def title(text):
    if text_color:
        print(f"\033[1;34m{text}\033[0m")
    else:
        print(text)

def has_permission():
    return os.geteuid() == 0

def get_input(prompt):
    return input(prompt)

def main():
    version = "1.8"

    def signal_handler(sig, frame):
        print("")
        print("[*] EXITING ...")
        print("")
        pb_write_log("exiting", "Core")
        exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    pb_write_log("pentbox loaded", "Core")

    random.seed(time.time())
    banner = random.randint(0, 3)

    print("")
    title(f" PenTBox {version} ")

    if banner == 0:
        print("                                     .::!!!!!!!:. ")
        print("  .!!!!!:.                        .:!!!!!!!!!!!! ")
        print("  ~~~~!!!!!!.                 .:!!!!!!!!!UWWW$$$ ")
        print("      :$$NWX!!:           .:!!!!!!XUWW$$$$$$$$$P ")
        print("      $$$$$##WX!:      .<!!!!UW$$$$   $$$$$$$$# ")
        print("      $$$$$  $$$UX   :!!UW$$$$$$$$$   4$$$$$* ")
        print("      ^$$$B  $$$$      $$$$$$$$$$$$   d$$R* ")
        print("        **$bd$$$$      '*$$$$$$$$$$$o+#  ")
        print("             ****          ******* ")
    elif banner == 1:
        print("         __")
        print("        U00U|.'@@@@@@`.")
        print("        |__|(@@@@@@@@@@)")
        print("             (@@@@@@@@)")
        print("             `YY~~~~YY'")
        print("              ||    ||")
    elif banner == 2:
        print("             .__.")
        print("             (oo)____")
        print("             (__)    )--*")
        print("                ||--|| ")
    elif banner == 3:
        print("    ____          _____ ____")
        print("   |  _ \\ ___ _ _|_   _| __ )  _____  __")
        print("   | |_) / _ \\ '_ \\| | |  _ \\ / _ \\ \\/ /")
        print("   |  __/  __/ | | | | | |_) | (_) >  <")
        print("   |_|   \\___|_| |_|_| |____/ \\___/_/\\_\\")

    time.sleep(0.25)
    option1 = ""

    while option1 != "8":
        module_exec = True
        print("")
        print("--------- Menu" + " "*10 + f"python {os.sys.version.split()[0]} @ {os.sys.platform}")
        print("")
        print("1- Cryptography tools")
        print("")
        print("2- Network tools")
        print("")
        print("3- Web")
        print("")
        print("4- Ip grabber")
        print("")
        print("5- Geolocation ip")
        print("")
        print("6- Mass attack")
        print("")
        print("7- License and contact")
        print("")
        print("8- Exit")
        print("")
        option1 = get_input("   -> ")
        print("")

        if option1 == "1":
            print("1- Base64 Encoder & Decoder")
            print("2- Multi-Digest (MD5, SHA1, SHA256, SHA384, SHA512, RIPEMD-160)")
            print("3- Hash Password Cracker (MD5, SHA1, SHA256, SHA384, SHA512, RIPEMD-160)")
            print("4- Secure Password Generator")
            print("")
            print("0- Back")
            print("")
            option2 = get_input("   -> ")
            if option2 == "0":
                module_exec = False
            elif option2 == "1":
                # Implement Base64 Encoder & Decoder
                pass
            elif option2 == "2":
                # Implement Multi-Digest
                pass
            elif option2 == "3":
                # Implement Hash Password Cracker
                pass
            elif option2 == "4":
                # Implement Secure Password Generator
                pass
            else:
                module_exec = False
                print("")
                print("Invalid option.")
                print("")
        elif option1 == "2":
            print("1- Net DoS Tester")
            print("2- TCP port scanner")
            print("3- Honeypot")
            print("4- Fuzzer")
            print("5- DNS and host gathering")
            print("6- MAC address geolocation (samy.pl)")
            print("")
            print("0- Back")
            print("")
            option2 = get_input("   -> ")
            if option2 == "0":
                module_exec = False
            elif option2 == "1":
                if has_permission():
                    # Implement Net DoS Tester
                    pass
                else:
                    module_exec = False
                    print("")
                    print("Sorry, you haven't permissions to run this module (root?).")
                    print("")
            elif option2 == "2":
                # Implement TCP port scanner
                pass
            elif option2 == "3":
                # Implement Honeypot
                pass
            elif option2 == "4":
                # Implement Fuzzer
                pass
            elif option2 == "5":
                # Implement DNS and host gathering
                pass
            elif option2 == "6":
                # Implement MAC address geolocation
                pass
            else:
                module_exec = False
                print("")
                print("Invalid option.")
                print("")
        elif option1 == "3":
            print("1- HTTP directory bruteforce")
            print("2- HTTP common files bruteforce")
            print("")
            print("0- Back")
            print("")
            option2 = get_input("   -> ")
            if option2 == "0":
                module_exec = False
            elif option2 == "1":
                # Implement HTTP directory bruteforce
                pass
            elif option2 == "2":
                # Implement HTTP common files bruteforce
                pass
            else:
                module_exec = False
                print("")
                print("Invalid option.")
                print("")
        elif option1 == "4":
            module_exec = False
            print("""
    X------------------------------------X
    | Copyright (C) 2012, 2013, 2014     |
    |                                    |
    |   Minzsec                          |
    |   www.facebook.com/rootnameshadow  |
    X------------------------------------X

    PenTBox is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    PenTBox is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with PenTBox. Or you need some configuration. If not, see <http://www.gnu.org/licenses/>.
""")
        elif option1 == "5":
            module_exec = False
            os.kill(os.getpid(), signal.SIGINT)  # Just exit.
        else:
            module_exec = False
            print("")
            print("Invalid option.")
            print("")

        if module_exec:
            print("")
            print("[*] Module execution finished.")
            print("")

if __name__ == "__main__":
    main()
