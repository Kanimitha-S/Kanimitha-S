import socket
import threading
import time
import os

def title(message):
    print(message)

def warning(message):
    print(f"Warning: {message}")

def honeyconfig(port, message, sound, log, logname):
    try:
        # Create a TCP server
        tcpserver = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        tcpserver.bind(("", port))
        tcpserver.listen(5)

        print(f"\n  HONEYPOT ACTIVATED ON PORT {port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")

        if log.lower() == "y":
            try:
                with open(logname, "a") as logf:
                    logf.write(f"#################### PenTBox Honeypot log\n")
                    logf.write(f"\n  HONEYPOT ACTIVATED ON PORT {port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")
            except FileNotFoundError:
                print("\n Saving log error: No such file or directory.\n")

        while True:
            # Accept incoming connections
            socket_client, addr = tcpserver.accept()
            time.sleep(1)  # To mitigate possible DoS attacks

            def handle_client(sock):
                remote_ip, remote_port = addr
                print(f"\n  INTRUSION ATTEMPT DETECTED! from {remote_ip}:{remote_port} ({time.strftime('%Y-%m-%d %H:%M:%S')})")
                print(" -----------------------------")
                reciv = sock.recv(1000).decode()
                print(reciv)
                if sound.lower() == "y":
                    print("\a\a\a")  # Beep sound

                if log.lower() == "y":
                    try:
                        with open(logname, "a") as logf:
                            logf.write(f"\n  INTRUSION ATTEMPT DETECTED! from {remote_ip}:{remote_port} ({time.strftime('%Y-%m-%d %H:%M:%S')})\n")
                            logf.write(" -----------------------------\n")
                            logf.write(reciv)
                    except FileNotFoundError:
                        print("\n Saving log error: No such file or directory.\n")

                time.sleep(2)  # Sticky honeypot
                sock.sendall(message.encode())
                sock.close()

            threading.Thread(target=handle_client, args=(socket_client,)).start()

    except PermissionError:
        print("\n Error: Honeypot requires root privileges.\n")
    except OSError as e:
        if e.errno == 98:  # Address already in use
            print("\n Error: Port in use.\n")
        else:
            print(f"\n Unknown error: {e}\n")

def main():
    print("\n// Honeypot //\n")
    warning("You must run PenTBox with root privileges.\n")
    print(" Select option.\n")
    print("1- Fast Auto Configuration")
    print("2- Manual Configuration [Advanced Users, more options]\n")
    configuration = input("   -> ").strip()

    if configuration == "1":
        import random
        access = random.randint(0, 2)
        if access == 0:
            honeyconfig(80, "<HEAD>\n<TITLE>Access denied</TITLE>\n</HEAD>\n<H2>Access denied</H2>\n" +
                       "<H3>HTTP Referrer login failed</H3>\n" +
                       "<H3>IP Address login failed</H3>\n" +
                       "<P>\n" + f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n</P>", "N", "N", "")
        elif access == 1:
            honeyconfig(80, "<HEAD>\n<TITLE>Access denied</TITLE>\n</HEAD>\n<H2>Access denied</H2>\n" +
                       "<H3>IP Address login failed</H3>\n" +
                       "<P>\n" + f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n</P>", "N", "N", "")
        elif access == 2:
            honeyconfig(80, "<HEAD>\n<TITLE>Access denied</TITLE>\n</HEAD>\n<H2>Access denied</H2>\n" +
                       "<P>\n" + f"{time.strftime('%Y-%m-%d %H:%M:%S')}\n</P>", "N", "N", "")
    elif configuration == "2":
        port = input("\n Insert port to Open.\n\n   -> ").strip()
        message = input("\n Insert false message to show.\n\n   -> ").strip()
        log = input("\n Save a log with intrusions?\n\n (y/n)   -> ").strip()
        logname = ""
        if log.lower() == "y":
            logname = input("\n Log file name? (incremental)\n\nDefault: */pentbox/other/log_honeypot.txt\n\n   -> ").strip()
            if not logname:
                logname = os.path.join(os.path.dirname(__file__), "../../other/log_honeypot.txt")
        sound = input("\n Activate beep() sound when intrusion?\n\n (y/n)   -> ").strip()
        honeyconfig(int(port), message, sound, log, logname)
    else:
        print("\nInvalid option.\n")

if __name__ == "__main__":
    main()
